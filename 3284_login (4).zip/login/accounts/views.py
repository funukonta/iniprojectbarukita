from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.forms.models import model_to_dict
from django.http import HttpResponse, HttpResponseRedirect
from accounts.models import Musictitle, Composer, Genre
from django.urls import reverse
from accounts.forms import ComposerForm, MusictitleForm, GenreForm

def indexView(request):
	return render(request, 'indexView.html')
@login_required
def dashboardView(request):
	return render(request, 'dashboard.html')

def registerView(request):
	if request.method == "POST":
		form = UserCreationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('login.url')
	else:
		form = UserCreationForm()
	return render(request,'register.html',{'form':form})

def index(request):
    # get all info here including authors, books, and genres
    num_musictitles = Musictitle.objects.all().count()
    num_composers = Composer.objects.all().count()
    num_genres = Genre.objects.all().count()
    context = {
        'num_musictitles': num_musictitles,
        'num_composers': num_composers,
        'num_genres' : num_genres,
    }
    return render(request, 'index.html', context=context)

def list_composers(request):
    # get all authors and add to context dictionary
    composers = Composer.objects.all()
    context = {
        'composers': composers,
    }
    # process the template and pass the context
    return render(request, 'composers.html', context=context)

def list_genres(request):
    # get all authors and add to context dictionary
    genres = Genre.objects.all()
    context = {
        'genres': genres,
    }
    # process the template and pass the context
    return render(request, 'genres.html', context=context)

def list_musictitles(request):
    # get all authors and add to context dictionary
    musictitles = Musictitle.objects.all()
    context = {
        'musictitles': musictitles,
    }
    # process the template and pass the context
    return render(request, 'musictitles.html', context=context)

def add_composer(request):
    if request.method == 'POST':
        form = ComposerForm(request.POST)
        if form.is_valid():
            form.save()  # directly save the form
            return HttpResponseRedirect(reverse('composers'))
    else:
        form = ComposerForm()

    context = {
        'form': form
    }
    return render(request, 'composer_form.html', context=context)


def edit_composer(request, composer_id):
    if request.method == 'POST':
        composer = Composer.objects.get(pk=composer_id)
        form = ComposerForm(request.POST, instance=composer)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('composers'))
    else:
        composer = Composer.objects.get(pk=composer_id)
        fields = model_to_dict(composer)
        form = ComposerForm(initial=fields, instance=composer)
    context = {
        'form': form,
        'type': 'edit',
    }
    return render(request, 'composer_form.html', context=context)

def delete_composer(request, composer_id):
    composer = Composer.objects.get(pk=composer_id)
    if request.method == 'POST':
        composer.delete()
        return HttpResponseRedirect(reverse('composers'))
    context = {
        'composer': composer
    }
    return render(request, 'composer_delete_form.html', context=context)


def add_musictitle(request):
    if request.method == 'POST':
        form = MusictitleForm(request.POST)
        if form.is_valid():
            form.save()  # directly save the form
            return HttpResponseRedirect(reverse('musictitles'))
    else:
        form = MusictitleForm()

    context = {
        'form': form
    }
    return render(request, 'musictitle_form.html', context=context)


def edit_musictitle(request, musictitle_id):
    if request.method == 'POST':
        musictitle = Musictitle.objects.get(pk=musictitle_id)
        form = MusictitleForm(request.POST, instance=musictitle)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('musictitles'))
    else:
        musictitle = Musictitle.objects.get(pk=musictitle_id)
        fields = model_to_dict(musictitle)
        form = MusictitleForm(initial=fields, instance=musictitle)
    context = {
        'form': form,
        'type': 'edit',
    }
    return render(request, 'musictitle_form.html', context=context)

def delete_musictitle(request, musictitle_id):
    musictitle = Musictitle.objects.get(pk=musictitle_id)
    if request.method == 'POST':
        musictitle.delete()
        return HttpResponseRedirect(reverse('musictitles'))
    context = {
        'musictitle': musictitle
    }
    return render(request, 'musictitle_delete_form.html', context=context)

def add_genre(request):
    if request.method == 'POST':
        form = GenreForm(request.POST)
        if form.is_valid():
            form.save()  # directly save the form
            return HttpResponseRedirect(reverse('genres'))
    else:
        form = GenreForm()

    context = {
        'form': form
    }
    return render(request, 'genre_form.html', context=context)


def edit_genre(request, genre_id):
    if request.method == 'POST':
       genre = Genre.objects.get(pk=genre_id)
       form = GenreForm(request.POST, instance=genre)
       if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('genres'))
    else:
        genre = Genre.objects.get(pk=genre_id)
        fields = model_to_dict(genre)
        form = GenreForm(initial=fields, instance=genre)
    context = {
        'form': form,
        'type': 'edit',
    }
    return render(request, 'genre_form.html', context=context)

def delete_genre(request, genre_id):
    genre = Genre.objects.get(pk=genre_id)
    if request.method == 'POST':
        genre.delete()
        return HttpResponseRedirect(reverse('genres'))
    context = {
        'genre': genre
    }  
    return render(request, 'genre_delete_form.html', context=context)

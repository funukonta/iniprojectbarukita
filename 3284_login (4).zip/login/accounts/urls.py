from django.urls import path
from.import views
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    path('',views.indexView, name='home'),
    path('dashboard/',views.dashboardView,name="dashboard"),
    path('login/',LoginView.as_view(),name="login_url"),
    path('register/',views.registerView,name="register_url"),
    path('register/login.url',views.registerView,name="register_url"),
    path('logout/',LogoutView.as_view(next_page='dashboard'),name="logout"),
    path('composers/', views.list_composers, name='composers'),
    path('composer/add', views.add_composer, name='add_composer'),
    path('composer/edit/<int:composer_id>', views.edit_composer, name='edit_composer'),
    path('composer/delete/<int:composer_id>', views.delete_composer, name='delete_composer'),
    path('genres/', views.list_genres, name='genres'),
    path('genre/add', views.add_genre, name='add_genre'),
    path('genre/edit/<int:genre_id>', views.edit_genre, name='edit_genre'),
    path('genre/delete/<int:genre_id>', views.delete_genre, name='delete_genre'),
    path('dashboard/', views.list_musictitles, name='musictitles'),
    path('dashboard/add/', views.add_musictitle, name='add_musictitle'),
    path('dashboard/edit/<int:musictitle_id>', views.edit_musictitle, name='edit_musictitle'),
    path('dashboard/delete/<int:musictitle_id>', views.delete_musictitle, name='delete_musictitle'),

]